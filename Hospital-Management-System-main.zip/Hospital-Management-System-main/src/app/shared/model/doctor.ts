export interface Doctor {
    id : string;
    name : string;
    mobile : string;
    email : string;
    qualification : string;
    gender : string;
    department : string;
    birthdate : Date
}
